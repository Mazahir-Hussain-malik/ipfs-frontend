import "./Global.css";
function Trash() {
  return (
    <div className="flex items-center justify-center files min-w-full min-h-full">
      <div className="text-gray-500">Coming Soon...</div>
    </div>
  )
}

export default Trash