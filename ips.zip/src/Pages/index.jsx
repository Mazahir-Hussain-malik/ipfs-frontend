export {default as Footer} from "./Footer";
export {default as Home} from "./Home";
export {default as Sidebar} from "./Sidebar";
export {default as Navbar} from "./Navbar";
export {default as UploadElement} from "./UploadElement";
export {default as Trash} from "./Trash"
export {default as Starred} from "./Starred";